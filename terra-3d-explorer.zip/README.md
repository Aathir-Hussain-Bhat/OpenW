# TERRA — 3D World Explorer

A real-time 3D globe you can spin, zoom and explore.

## Run it

```bash
npx serve dist            # or: python3 -m http.server -d dist 8080
```

Open http://localhost:8080. It must be served over HTTP — Cesium loads Web Workers and map
tiles, which browsers block on `file://`.

## What's inside
- **Live satellite imagery** — Esri World Imagery, plus NASA GIBS Blue Marble and Blue Marble
  Shaded Relief. No API keys, no accounts, no rate-limit tokens.
- **A true day/night terminator** — the sun follows a real solar-position model, and NASA VIIRS
  night lights fade in on the dark side (tinted sodium-amber, alpha-masked so the imagery shows
  through).
- **34,000 searchable places** — offline GeoNames index for every city over 15,000 people, plus
  every country, plus 40 hand-picked landmarks. Falls back to live Photon/OSM geocoding.
- **Procedural 3D landmark models** — the Eiffel Tower, Giza, the Taj Mahal, Angkor Wat, Everest
  and more are built from primitives and materialise as you approach.
- Click anything for coordinates and a reverse-geocoded place name.

## Controls
| Action | Result |
|---|---|
| Drag | Spin the globe |
| Scroll / pinch | Zoom |
| Click a place, border, city or landmark | Open the info card |
| `Imagery` | Satellite / Blue Marble / Relief |
| `Sun` slider + date | Move the terminator and the night lights |
| `Layers` | Toggle borders, city labels, night lights, auto-rotate |
| Search box | Type a place, arrow-keys + Enter to pick |

## Credits
- Imagery: Esri World Imagery · NASA EOSDIS GIBS (Blue Marble, VIIRS Night Lights)
- Boundaries: Natural Earth (public domain)
- Places: GeoNames (CC BY 4.0)
- Geocoding fallback: Photon / OpenStreetMap
- Engine: CesiumJS (Apache 2.0)
